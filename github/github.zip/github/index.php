<?php
header('Location: login.html');
exit
?>
